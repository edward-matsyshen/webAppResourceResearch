# Project Excelsior

## Table of Contents
* [General Info](#general-information)
* [Technologies Used](#technologies-used)
* [Features](#features)
* [Usage](#usage)
* [Project Status](#project-status)
* [Room for Improvement](#room-for-improvement)
* [Acknowledgements](#acknowledgements)


## General Information
- 

## Technologies Used
Project is created with:
* Node.JS
* JQuery
* HTML/CSS/JS
* NPM

## Features
- 

## Usage


## Project Status
Project is: _in progress_ 

## Room for Improvement
Room for improvement:
- 

To do:
- 

## Acknowledgements
- 

