# HW2
second hw assignment 
